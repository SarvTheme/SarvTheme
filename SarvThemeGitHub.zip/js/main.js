import ScrollToAnchor from './scrolltoanchor.esm.js';
var smoothScroll = new ScrollToAnchor({
    duration: 2000,
    offset : 70
});